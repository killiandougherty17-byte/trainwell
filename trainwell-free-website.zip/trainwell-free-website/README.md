# TrainWell — free starter website

A mobile-friendly fitness tracker and installable PWA starter. It is a static website and can be hosted free on GitHub Pages, Cloudflare Pages, or another static host.

## Features in this starter
- Workout tracker with exercises, sets, reps, weights, completion checkboxes and session notes
- Two-minute rest timer, pause/resume, reset and +30 seconds
- Weekly workout split planner and text/CSV split import
- Video preview and plan draft from the user's written description
- Food logging with manually entered calorie/macronutrient estimates
- Food photo preview and long-term training goals
- JSON data backup and restore
- Responsive layout and PWA manifest/service worker

## Important limitations
- Workout/food/goal data is stored in the browser's local storage on that device. There are no accounts or cloud sync.
- Photo upload does not automatically identify food or calculate macros.
- Video upload previews the clip but does not automatically analyze it. The draft uses the written description.
- This is a starter project, not a medical or diet prescription tool. Nutrition estimates are approximate.

## Publish for free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new **public** repository named `trainwell`.
3. Upload all files in this folder to the repository's root (make sure `index.html` is at the root).
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the deployment. GitHub will show the live URL in Settings → Pages, typically `https://YOUR-USERNAME.github.io/trainwell/`.
7. Open the link on your phone. On iPhone use Safari → Share → Add to Home Screen. On Android use Chrome's menu → Install app or Add to Home screen.

GitHub's interface can change; follow its current prompts if labels differ.

## Editing
Edit `index.html` for the app interface and behavior, `manifest.webmanifest` for app metadata, and `sw.js` for offline caching. After updates, redeploy the changed files.

## Privacy
This starter uses browser local storage and does not send workout or food logs to a server. Do not enter sensitive information on a shared device.
